package com.example.demo;

import java.util.List;

public class RoomBookingResponse {

	private String room_amenties;
	private List<String> locationList;
	
	
}
